<?php
/*
Plugin Name: PSP News Feed
Plugin URI: https://www.LSDigitalSolutions.com				
Description: Members-only news feed of articles mentioning the Pennsylvania State Police. Automatically creates posts in your News custom post type. Use shortcode [psp_news_feed] on any page. Updated with additional Shortcodes

Version: 1.1.9
Author: Lucien R Southard
License: GPL2
*/

// Block direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ── CONSTANTS ──────────────────────────────────────────────────────────────
define( 'PSP_CACHE_KEY',      'psp_news_cache' );
define( 'PSP_CACHE_TIME',     3600 );   // Feed cache: 1 hour
define( 'PSP_MAX_ITEMS',      30 );
define( 'PSP_RSS_URL',        'https://news.google.com/rss/search?q=%22Pennsylvania+State+Police%22&hl=en-US&gl=US&ceid=US:en' );
define( 'PSP_POST_TYPE',      'news' ); // Your custom post type slug
define( 'PSP_POST_STATUS',    'pending' ); // Auto-created posts: pending review
define( 'PSP_POST_AUTHOR',    1 );      // Author ID for auto-created posts (1 = admin)
define( 'PSP_EXPIRE_DAYS',    30 );     // Auto-delete posts older than this many days
define( 'PSP_META_KEY',       '_psp_news_url' ); // Meta key to track auto-created posts

// ── ACTIVATION / DEACTIVATION ──────────────────────────────────────────────
function psp_activate() {
    if ( ! wp_next_scheduled( 'psp_cron_hook' ) ) {
        wp_schedule_event( time(), 'hourly', 'psp_cron_hook' );
    }
    if ( ! wp_next_scheduled( 'psp_autopost_hook' ) ) {
        wp_schedule_event( time(), 'hourly', 'psp_autopost_hook' );
    }
    if ( ! wp_next_scheduled( 'psp_cleanup_hook' ) ) {
        wp_schedule_event( time(), 'daily', 'psp_cleanup_hook' );
    }
}
register_activation_hook( __FILE__, 'psp_activate' );

function psp_deactivate() {
    wp_clear_scheduled_hook( 'psp_cron_hook' );
    wp_clear_scheduled_hook( 'psp_autopost_hook' );
    wp_clear_scheduled_hook( 'psp_cleanup_hook' );
    delete_transient( PSP_CACHE_KEY );
}
register_deactivation_hook( __FILE__, 'psp_deactivate' );

add_action( 'psp_cron_hook',     'psp_fetch_feed' );
add_action( 'psp_autopost_hook', 'psp_auto_create_posts' );
add_action( 'psp_cleanup_hook',  'psp_cleanup_old_posts' );

// ── SORT HELPER ─────────────────────────────────────────────────────────────
function psp_sort_by_date( $a, $b ) {
    return $b['timestamp'] - $a['timestamp']; // Descending: newest first
}

// ── FETCH RSS FEED ──────────────────────────────────────────────────────────
function psp_fetch_feed() {
    $response = wp_remote_get( PSP_RSS_URL, array(
        'timeout'    => 20,
        'user-agent' => 'WordPress/' . get_bloginfo( 'version' ),
    ) );

    if ( is_wp_error( $response ) ) {
        return array();
    }

    $code = wp_remote_retrieve_response_code( $response );
    if ( $code !== 200 ) {
        return array();
    }

    $body = wp_remote_retrieve_body( $response );
    if ( empty( $body ) ) {
        return array();
    }

    // Suppress XML parse errors
    $prev = libxml_use_internal_errors( true );
    $xml  = simplexml_load_string( $body );
    libxml_use_internal_errors( $prev );

    if ( false === $xml || ! isset( $xml->channel->item ) ) {
        return array();
    }

    $articles = array();
    $i        = 0;

    foreach ( $xml->channel->item as $item ) {
        if ( $i >= PSP_MAX_ITEMS ) {
            break;
        }

        $title    = isset( $item->title )       ? (string) $item->title       : '';
        $link     = isset( $item->link )        ? (string) $item->link        : '';
        $pubdate  = isset( $item->pubDate )     ? (string) $item->pubDate     : '';
        $source   = isset( $item->source )      ? (string) $item->source      : 'Unknown';
        $desc     = isset( $item->description ) ? (string) $item->description : '';

        // Clean title — Google News appends " - Source Name" to titles, strip it
        $source_name = sanitize_text_field( (string) $source );
        $title = preg_replace( '/ - ' . preg_quote( $source_name, '/' ) . '$/', '', $title );
        $title = trim( $title );

        // Clean description — Google News wraps content in HTML tables
        // Decode HTML entities first, then strip all tags
        $desc = html_entity_decode( $desc, ENT_QUOTES, 'UTF-8' );
        $desc = wp_strip_all_tags( $desc );
        // Remove any leftover whitespace/newlines
        $desc = preg_replace( '/\s+/', ' ', $desc );
        $desc = trim( $desc );
        // Trim to ~200 chars at a word boundary
        if ( strlen( $desc ) > 200 ) {
            $desc = substr( $desc, 0, 200 );
            $last_space = strrpos( $desc, ' ' );
            if ( $last_space !== false ) {
                $desc = substr( $desc, 0, $last_space );
            }
            $desc = $desc . '...';
        }

        $ts        = strtotime( $pubdate );
        $formatted = $ts ? date( 'M j, Y g:i a', $ts ) : $pubdate;

        $articles[] = array(
            'title'     => sanitize_text_field( $title ),
            'link'      => esc_url_raw( $link ),
            'source'    => sanitize_text_field( $source ),
            'date'      => $formatted,
            'timestamp' => $ts ? $ts : 0,
            'desc'      => sanitize_text_field( $desc ),
        );

        $i++;
    }

    // Sort by timestamp descending (newest first)
    usort( $articles, 'psp_sort_by_date' );

    set_transient( PSP_CACHE_KEY, $articles, PSP_CACHE_TIME );
    return $articles;
}

function psp_get_articles() {
    $cached = get_transient( PSP_CACHE_KEY );
    if ( false !== $cached ) {
        return $cached;
    }
    return psp_fetch_feed();
}

// ── AUTO-CREATE NEWS POSTS ───────────────────────────────────────────────────
function psp_auto_create_posts() {
    $articles = psp_get_articles();

    if ( empty( $articles ) ) {
        return;
    }

    foreach ( $articles as $article ) {
        if ( empty( $article['link'] ) || empty( $article['title'] ) ) {
            continue;
        }

        // Check if a post already exists for this URL — avoid duplicates
        $existing = get_posts( array(
            'post_type'   => PSP_POST_TYPE,
            'post_status' => array( 'publish', 'pending', 'draft', 'trash' ),
            'meta_key'    => PSP_META_KEY,
            'meta_value'  => $article['link'],
            'numberposts' => 1,
            'fields'      => 'ids',
        ) );

        if ( ! empty( $existing ) ) {
            continue; // Already exists — skip
        }

        // Build post content with snippet + source attribution + link
        $content  = '';
        if ( ! empty( $article['desc'] ) ) {
            $content .= '<p>' . esc_html( $article['desc'] ) . '</p>';
        }
        $content .= '<p><strong>Source:</strong> ' . esc_html( $article['source'] ) . '</p>';
        $content .= '<p><a href="' . esc_url( $article['link'] ) . '" target="_blank" rel="noopener noreferrer">Read the full article &rarr;</a></p>';
        $content .= '<p><em>&#9432; This article was automatically sourced from Google News. The PSPRA is not responsible for the content of externally linked news articles.</em></p>';

        // Set post date from the article's published timestamp
        $post_date = ! empty( $article['timestamp'] ) ? date( 'Y-m-d H:i:s', $article['timestamp'] ) : current_time( 'mysql' );

        $post_id = wp_insert_post( array(
            'post_title'    => $article['title'],
            'post_content'  => $content,
            'post_status'   => PSP_POST_STATUS,
            'post_type'     => PSP_POST_TYPE,
            'post_author'   => PSP_POST_AUTHOR,
            'post_date'     => $post_date,
            'post_date_gmt' => get_gmt_from_date( $post_date ),
        ) );

        if ( $post_id && ! is_wp_error( $post_id ) ) {
            // Store the source URL as meta so we can detect duplicates later
            update_post_meta( $post_id, PSP_META_KEY, $article['link'] );
            // Store creation date for cleanup
            update_post_meta( $post_id, '_psp_auto_created', current_time( 'mysql' ) );
        }
    }
}

// ── CLEANUP OLD AUTO-CREATED POSTS ──────────────────────────────────────────
function psp_cleanup_old_posts() {
    $cutoff = date( 'Y-m-d H:i:s', strtotime( '-' . PSP_EXPIRE_DAYS . ' days' ) );

    $old_posts = get_posts( array(
        'post_type'   => PSP_POST_TYPE,
        'post_status' => array( 'publish', 'pending', 'draft' ),
        'numberposts' => 100,
        'fields'      => 'ids',
        'meta_query'  => array(
            array(
                'key'     => '_psp_auto_created',
                'value'   => $cutoff,
                'compare' => '<=',
                'type'    => 'DATETIME',
            ),
        ),
    ) );

    if ( empty( $old_posts ) ) {
        return;
    }

    foreach ( $old_posts as $post_id ) {
        wp_delete_post( $post_id, true ); // true = bypass trash, delete permanently
    }
}

// ── STYLES ──────────────────────────────────────────────────────────────────
function psp_styles() {
    echo '<style>
.psp-wrap { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; max-width: 860px; margin: 0 auto; }
.psp-header { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 10px; padding-bottom: 12px; border-bottom: 3px solid #002868; margin-bottom: 18px; }
.psp-header h3 { margin: 0; color: #002868; font-size: 1.3em; }
.psp-count { background: #002868; color: #fff; border-radius: 10px; padding: 2px 8px; font-size: 0.75em; margin-left: 6px; }
.psp-refresh { background: #002868; color: #fff; padding: 6px 12px; border-radius: 4px; text-decoration: none; font-size: 0.82em; }
.psp-refresh:hover { background: #BF0A30; color: #fff; }
.psp-meta { font-size: 0.78em; color: #888; }
.psp-list { list-style: none; padding: 0; margin: 0; }
.psp-item { padding: 14px 0; border-bottom: 1px solid #eee; }
.psp-item:last-child { border-bottom: none; }
.psp-item a { font-weight: 600; color: #002868; text-decoration: none; font-size: 0.98em; line-height: 1.4; display: block; }
.psp-item a:hover { color: #BF0A30; text-decoration: underline; }
.psp-item-meta { font-size: 0.78em; color: #888; margin-top: 3px; }
.psp-item-meta strong { color: #555; }
.psp-snippet { font-size: 0.84em; color: #555; margin-top: 4px; line-height: 1.5; }
.psp-empty { padding: 30px; text-align: center; background: #f5f5f5; border-radius: 6px; color: #666; }
.psp-disclaimer { margin-top: 18px; padding: 10px 14px; background: #f0f4ff; border-left: 4px solid #002868; border-radius: 3px; font-size: 0.78em; color: #555; line-height: 1.5; }
</style>';
}

// ── SHORTCODE ────────────────────────────────────────────────────────────────
function psp_shortcode( $atts ) {
    // Login gate
    if ( ! is_user_logged_in() ) {
        psp_styles();
        $login_url = wp_login_url( get_permalink() );
        return '<div class="psp-login">&#128274; <strong>Members only.</strong> Please <a href="' . esc_url( $login_url ) . '">log in</a> to view the PSP News Feed.</div>';
    }

    // Manual refresh
    if ( isset( $_GET['psp_refresh'] ) && '1' === $_GET['psp_refresh'] ) {
        delete_transient( PSP_CACHE_KEY );
    }

    $articles    = psp_get_articles();
    $count       = is_array( $articles ) ? count( $articles ) : 0;
    $refresh_url = esc_url( add_query_arg( 'psp_refresh', '1' ) );

    ob_start();
    psp_styles();
    ?>
    <div class="psp-wrap">
        <div class="psp-header">
            <h3>Pennsylvania State Police News <span class="psp-count"><?php echo intval( $count ); ?> articles</span></h3>
            <div>
                <span class="psp-meta">Auto-updates hourly &bull; Google News &nbsp;</span>
                <a class="psp-refresh" href="<?php echo $refresh_url; ?>">&#8635; Refresh</a>
            </div>
        </div>

        <?php if ( empty( $articles ) ) : ?>
            <div class="psp-empty">
                <p>&#9888; No articles loaded yet. <a href="<?php echo $refresh_url; ?>">Click here to refresh.</a></p>
            </div>
        <?php else : ?>
            <ul class="psp-list">
                <?php foreach ( $articles as $a ) : ?>
                <li class="psp-item">
                    <a href="<?php echo esc_url( $a['link'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $a['title'] ); ?></a>
                    <div class="psp-item-meta"><strong><?php echo esc_html( $a['source'] ); ?></strong> &bull; <?php echo esc_html( $a['date'] ); ?></div>
                    <?php if ( ! empty( $a['desc'] ) ) : ?>
                    <div class="psp-snippet"><?php echo esc_html( $a['desc'] ); ?></div>
                    <?php endif; ?>
                </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>

        <div class="psp-disclaimer">
            <strong>Disclaimer:</strong> The Pennsylvania State Police Retirees Association (PSPRA) is not responsible for the content of any news articles displayed in this feed. All articles are sourced automatically from Google News and represent the views of their respective publishers. Links to external sites do not constitute endorsement by the PSPRA.
        </div>

    </div>
    <?php
    return ob_get_clean();
}
add_shortcode( 'psp_news_feed', 'psp_shortcode' );

// ── RECENT NEWS CARDS SHORTCODE [psp_news_recent] ────────────────────────────
function psp_recent_shortcode( $atts ) {

    $atts = shortcode_atts( array( 'count' => 4 ), $atts );
    $count = max( 1, min( 12, intval( $atts['count'] ) ) );

    // Members only gate
    if ( ! is_user_logged_in() ) {
        $login_url = wp_login_url( get_permalink() );
        return '<div class="psp-login">&#128274; <strong>Members only.</strong> Please <a href="' . esc_url( $login_url ) . '">log in</a> to view the latest PSP news.</div>';
    }

    $articles = psp_get_articles();

    if ( empty( $articles ) ) {
        return '<p style="color:#888;">No PSP news articles available at this time.</p>';
    }

    $recent = array_slice( $articles, 0, $count );

    ob_start();
    ?>
    <style>
    .psp-cards-wrap { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; margin: 0 0 10px 0; }
    .psp-cards-heading { font-size: 1.05em; font-weight: 700; color: #002868; margin: 0 0 14px 0; padding-bottom: 8px; border-bottom: 2px solid #002868; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px; }
    .psp-cards-heading a { font-size: 0.78em; font-weight: normal; color: #002868; text-decoration: underline; }
    .psp-cards-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin: 0; padding: 0; list-style: none; }
    .psp-card { background: #fff; border: 1px solid #dde3f0; border-radius: 6px; padding: 16px; display: flex; flex-direction: column; gap: 8px; box-shadow: 0 1px 4px rgba(0,0,0,0.06); transition: box-shadow 0.2s; }
    .psp-card:hover { box-shadow: 0 3px 10px rgba(0,40,104,0.12); }
    .psp-card-source { font-size: 0.72em; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: #BF0A30; }
    .psp-card-title a { font-size: 0.92em; font-weight: 600; color: #002868; text-decoration: none; line-height: 1.4; display: block; }
    .psp-card-title a:hover { color: #BF0A30; text-decoration: underline; }
    .psp-card-date { font-size: 0.72em; color: #999; margin-top: auto; }
    .psp-cards-disclaimer { font-size: 0.72em; color: #aaa; margin-top: 12px; line-height: 1.5; }
    @media ( max-width: 600px ) { .psp-cards-grid { grid-template-columns: 1fr; } }
    </style>

    <div class="psp-cards-wrap">
        <div class="psp-cards-heading">
            Latest PSP News
            <a href="https://dev.round4cloud.com/psp-retirees-association/test-psp-news-feed/">View all &rarr;</a>
        </div>
        <ul class="psp-cards-grid">
            <?php foreach ( $recent as $a ) : ?>
            <li class="psp-card">
                <div class="psp-card-source"><?php echo esc_html( $a['source'] ); ?></div>
                <div class="psp-card-title">
                    <a href="<?php echo esc_url( $a['link'] ); ?>" target="_blank" rel="noopener noreferrer">
                        <?php echo esc_html( $a['title'] ); ?>
                    </a>
                </div>
                <div class="psp-card-date"><?php echo esc_html( $a['date'] ); ?></div>
            </li>
            <?php endforeach; ?>
        </ul>
        <div class="psp-cards-disclaimer">&#9432; PSPRA is not responsible for the content of externally linked news articles.</div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode( 'psp_news_recent', 'psp_recent_shortcode' );

// ── SINGLE TILE SHORTCODE [psp_news_tile n="1"] ──────────────────────────────
function psp_tile_shortcode( $atts ) {

    $atts = shortcode_atts( array( 'n' => 1 ), $atts );
    $n    = max( 1, min( 10, intval( $atts['n'] ) ) );

    // Members only gate
    if ( ! is_user_logged_in() ) {
        return '';  // Silent — show nothing to guests on homepage
    }

    $articles = psp_get_articles();

    if ( empty( $articles ) || ! isset( $articles[ $n - 1 ] ) ) {
        return '';  // Silent — no broken placeholder if feed is empty
    }

    $a = $articles[ $n - 1 ];

    ob_start();
    ?>
    <style>
    .psp-tile { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background: #fff; border: 1px solid #dde3f0; border-radius: 6px; padding: 16px; display: flex; flex-direction: column; gap: 8px; box-shadow: 0 1px 4px rgba(0,0,0,0.06); transition: box-shadow 0.2s; margin-bottom: 12px; }
    .psp-tile:hover { box-shadow: 0 3px 10px rgba(0,40,104,0.12); }
    .psp-tile-label { font-size: 0.68em; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: #fff; background: #BF0A30; display: inline-block; padding: 2px 7px; border-radius: 3px; width: fit-content; }
    .psp-tile-source { font-size: 0.72em; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: #BF0A30; }
    .psp-tile-title a { font-size: 0.95em; font-weight: 600; color: #002868; text-decoration: none; line-height: 1.45; display: block; }
    .psp-tile-title a:hover { color: #BF0A30; text-decoration: underline; }
    .psp-tile-snippet { font-size: 0.83em; color: #444; line-height: 1.55; }
    .psp-tile-date { font-size: 0.72em; color: #999; }
    .psp-tile-footer { font-size: 0.68em; color: #bbb; border-top: 1px solid #f0f0f0; padding-top: 8px; margin-top: 4px; }
    </style>

    <div class="psp-tile">
        <div class="psp-tile-label">PSP News</div>
        <div class="psp-tile-source"><?php echo esc_html( $a['source'] ); ?></div>
        <div class="psp-tile-title">
            <a href="<?php echo esc_url( $a['link'] ); ?>" target="_blank" rel="noopener noreferrer">
                <?php echo esc_html( $a['title'] ); ?>
            </a>
        </div>
        <?php if ( ! empty( $a['desc'] ) ) : ?>
        <div class="psp-tile-snippet"><?php echo esc_html( $a['desc'] ); ?></div>
        <?php endif; ?>
        <div class="psp-tile-date"><?php echo esc_html( $a['date'] ); ?></div>
        <div class="psp-tile-footer">&#9432; PSPRA is not responsible for external news content.</div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode( 'psp_news_tile', 'psp_tile_shortcode' );

// ── TITLE-ONLY SHORTCODE [psp_news_title n="1"] ──────────────────────────────
// Outputs just the article headline as a styled heading — use this to replace
// a manual title block. Accepts optional 'tag' attribute for heading level.
// Examples:
//   [psp_news_title n="1"]         → <h2> heading (default)
//   [psp_news_title n="1" tag="h3"] → <h3> heading
function psp_title_shortcode( $atts ) {

    $atts = shortcode_atts( array(
        'n'   => 1,
        'tag' => 'h2',
    ), $atts );

    $n   = max( 1, min( 10, intval( $atts['n'] ) ) );
    $tag = in_array( $atts['tag'], array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'span' ), true ) ? $atts['tag'] : 'h2';

    // Members only — silent on front end
    if ( ! is_user_logged_in() ) {
        return '';
    }

    $articles = psp_get_articles();

    if ( empty( $articles ) || ! isset( $articles[ $n - 1 ] ) ) {
        return '';
    }

    $a     = $articles[ $n - 1 ];
    $title = esc_html( $a['title'] );
    $link  = esc_url( $a['link'] );

    return '<' . $tag . ' class="psp-news-headline" style="margin:0 0 4px 0;"><a href="' . $link . '" target="_blank" rel="noopener noreferrer" style="color:inherit;text-decoration:none;">' . $title . '</a></' . $tag . '>';
}
add_shortcode( 'psp_news_title', 'psp_title_shortcode' );

// ── ADMIN DASHBOARD WIDGET ───────────────────────────────────────────────────
function psp_dashboard_widget_render() {
    $articles = psp_get_articles();
    if ( empty( $articles ) ) {
        echo '<p>No articles. <a href="' . esc_url( admin_url( 'options-general.php?page=psp-news' ) ) . '">Go to settings to refresh.</a></p>';
        return;
    }
    $items = array_slice( $articles, 0, 8 );
    echo '<ul style="margin:0;padding:0;list-style:none;">';
    foreach ( $items as $a ) {
        echo '<li style="padding:7px 0;border-bottom:1px solid #eee;">';
        echo '<a href="' . esc_url( $a['link'] ) . '" target="_blank" style="font-weight:600;color:#002868;text-decoration:none;">' . esc_html( $a['title'] ) . '</a>';
        echo '<br><small style="color:#999;">' . esc_html( $a['source'] ) . ' &bull; ' . esc_html( $a['date'] ) . '</small>';
        echo '</li>';
    }
    echo '</ul>';
}

function psp_add_dashboard_widget() {
    wp_add_dashboard_widget( 'psp_widget', 'PSP News — Latest Headlines', 'psp_dashboard_widget_render' );
}
add_action( 'wp_dashboard_setup', 'psp_add_dashboard_widget' );

// ── SETTINGS PAGE ────────────────────────────────────────────────────────────
function psp_settings_page() {

    // Handle feed refresh
    if ( isset( $_POST['psp_do_refresh'] ) && check_admin_referer( 'psp_refresh_nonce' ) ) {
        delete_transient( PSP_CACHE_KEY );
        $articles = psp_fetch_feed();
        $msg      = is_array( $articles ) ? count( $articles ) : 0;
        echo '<div class="notice notice-success"><p>&#10003; Feed refreshed &mdash; ' . intval( $msg ) . ' articles loaded.</p></div>';
    }

    // Handle manual auto-post trigger
    if ( isset( $_POST['psp_do_autopost'] ) && check_admin_referer( 'psp_refresh_nonce' ) ) {
        psp_auto_create_posts();
        echo '<div class="notice notice-success"><p>&#10003; Auto-post complete. Check <a href="' . esc_url( admin_url( 'edit.php?post_type=' . PSP_POST_TYPE . '&post_status=pending' ) ) . '">Pending ' . esc_html( PSP_POST_TYPE ) . ' posts</a> for new articles.</p></div>';
    }

    // Handle manual cleanup trigger
    if ( isset( $_POST['psp_do_cleanup'] ) && check_admin_referer( 'psp_refresh_nonce' ) ) {
        psp_cleanup_old_posts();
        echo '<div class="notice notice-success"><p>&#10003; Cleanup complete. Posts older than ' . PSP_EXPIRE_DAYS . ' days have been deleted.</p></div>';
    }

    $articles      = psp_get_articles();
    $count         = is_array( $articles ) ? count( $articles ) : 0;
    $next_feed     = wp_next_scheduled( 'psp_cron_hook' );
    $next_post     = wp_next_scheduled( 'psp_autopost_hook' );
    $next_cleanup  = wp_next_scheduled( 'psp_cleanup_hook' );
    $next_feed_t   = $next_feed    ? date( 'M j, Y g:i a', $next_feed )    : 'Not scheduled';
    $next_post_t   = $next_post    ? date( 'M j, Y g:i a', $next_post )    : 'Not scheduled';
    $next_clean_t  = $next_cleanup ? date( 'M j, Y g:i a', $next_cleanup ) : 'Not scheduled';

    // Count existing auto-created posts
    $auto_posts = get_posts( array(
        'post_type'   => PSP_POST_TYPE,
        'post_status' => array( 'publish', 'pending', 'draft' ),
        'numberposts' => -1,
        'fields'      => 'ids',
        'meta_key'    => PSP_META_KEY,
    ) );
    $auto_count = count( $auto_posts );
    ?>
    <div class="wrap">
        <h1>PSP News Feed — Settings</h1>

        <h2>Feed Status</h2>
        <table class="form-table">
            <tr><th>Shortcodes</th><td><code>[psp_news_feed]</code> &nbsp; <code>[psp_news_recent]</code> &nbsp; <code>[psp_news_tile n="1"]</code> &nbsp; <code>[psp_news_title n="1"]</code></td></tr>
            <tr><th>Articles in cache</th><td><?php echo intval( $count ); ?></td></tr>
            <tr><th>Next feed refresh</th><td><?php echo esc_html( $next_feed_t ); ?></td></tr>
            <tr><th>RSS Source</th><td><a href="<?php echo esc_url( PSP_RSS_URL ); ?>" target="_blank">Google News — Pennsylvania State Police</a></td></tr>
        </table>

        <h2>Auto-Post to News</h2>
        <table class="form-table">
            <tr><th>Post type</th><td><code><?php echo esc_html( PSP_POST_TYPE ); ?></code></td></tr>
            <tr><th>Post status</th><td>Pending Review (you approve before publishing)</td></tr>
            <tr><th>Auto-created posts</th><td><?php echo intval( $auto_count ); ?> &mdash; <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=' . PSP_POST_TYPE . '&post_status=pending' ) ); ?>">View pending &rarr;</a></td></tr>
            <tr><th>Next auto-post run</th><td><?php echo esc_html( $next_post_t ); ?></td></tr>
            <tr><th>Auto-cleanup</th><td>Posts older than <?php echo PSP_EXPIRE_DAYS; ?> days deleted automatically</td></tr>
            <tr><th>Next cleanup run</th><td><?php echo esc_html( $next_clean_t ); ?></td></tr>
        </table>

        <h2>Manual Controls</h2>
        <form method="post" style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;">
            <?php wp_nonce_field( 'psp_refresh_nonce' ); ?>
            <input type="submit" name="psp_do_refresh"  class="button button-primary" value="&#8635; Refresh Feed Cache">
            <input type="submit" name="psp_do_autopost" class="button button-primary" value="&#43; Create News Posts Now">
            <input type="submit" name="psp_do_cleanup"  class="button button-secondary" value="&#128465; Run Cleanup Now"
                onclick="return confirm('This will permanently delete auto-created posts older than <?php echo PSP_EXPIRE_DAYS; ?> days. Continue?');">
        </form>

        <?php if ( ! empty( $articles ) ) : ?>
        <h2 style="margin-top:28px;">Latest 5 Articles in Feed</h2>
        <ul>
            <?php foreach ( array_slice( $articles, 0, 5 ) as $a ) : ?>
            <li><a href="<?php echo esc_url( $a['link'] ); ?>" target="_blank"><?php echo esc_html( $a['title'] ); ?></a> &mdash; <em style="color:#888;"><?php echo esc_html( $a['source'] ); ?>, <?php echo esc_html( $a['date'] ); ?></em></li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>
    </div>
    <?php
}

function psp_admin_menu() {
    add_options_page( 'PSP News Feed', 'PSP News Feed', 'manage_options', 'psp-news', 'psp_settings_page' );
}
add_action( 'admin_menu', 'psp_admin_menu' );
